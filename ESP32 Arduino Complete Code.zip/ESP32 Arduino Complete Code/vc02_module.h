#ifndef VC02_MODULE_H
#define VC02_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "state.h"
#include "relay_module.h"
#include "sim800_module.h"

// ═══════════════════════════════════════════════════════════════════
// UART OBJECT
// ═══════════════════════════════════════════════════════════════════
HardwareSerial VC02Serial(1);

// ═══════════════════════════════════════════════════════════════════
// RECEIVED VALUE
// ═══════════════════════════════════════════════════════════════════
unsigned int vc02ReceivedValue = 0;

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setupVC02()
{
  VC02Serial.begin(9600, SERIAL_8N1, VC02_RX_PIN, VC02_TX_PIN);
  delay(100);
  Serial.println(F("✓ VC-02 initialized"));
}

// ═══════════════════════════════════════════════════════════════════
// EMERGENCY TRIGGER
// ═══════════════════════════════════════════════════════════════════
void triggerEmergency(String source)
{
  state.emergencyActive = true;
  state.lastCommand = "EMERGENCY";
  state.lastSource = source;

  Serial.println(F("🚨 EMERGENCY ALERT!"));
  Serial.print(F("   Source: "));
  Serial.println(source);
  logEvent("Emergency triggered via " + source);

  // Buzzer always works
  triggerBuzzer();

  // SMS only if network ready
  if (netState.networkReady)
  {
    String msg = "EMERGENCY ALERT!\nLocation: " + PATIENT_BED +
                 "\nPatient requires IMMEDIATE assistance!";
    sendSMS(DOCTOR_PHONE, msg);
  }
  else
  {
    Serial.println(F("⚠️ Network not ready - SMS skipped"));
  }

  sendStateToApp();
}

void clearEmergency(String source)
{
  state.emergencyActive = false;
  state.lastCommand = "EMERGENCY_CLEAR";
  state.lastSource = source;

  stopBuzzer();

  Serial.println(F("✅ Emergency cleared"));
  Serial.print(F("   Source: "));
  Serial.println(source);
  logEvent("Emergency cleared via " + source);

  sendStateToApp();
}

// ═══════════════════════════════════════════════════════════════════
// CALL NURSE
// ═══════════════════════════════════════════════════════════════════
void callNurse(String source)
{
  state.nurseCallActive = true;
  state.lastCommand = "CALL_NURSE";
  state.lastSource = source;

  Serial.println(F("📞 Call Nurse"));
  logEvent("Nurse call triggered via " + source);

  if (netState.networkReady)
  {
    String msg = "Nurse Call Request\nLocation: " + PATIENT_BED +
                 "\nPatient needs assistance.";
    sendSMS(NURSE_PHONE, msg);
  }
  else
  {
    Serial.println(F("⚠️ Network not ready - SMS pending"));
  }

  sendStateToApp();
}

void acknowledgeNurseCall(String source)
{
  state.nurseCallActive = false;
  state.lastCommand = "NURSE_ACK";
  state.lastSource = source;

  Serial.println(F("✅ Nurse call acknowledged"));
  Serial.print(F("   Source: "));
  Serial.println(source);
  logEvent("Nurse call acknowledged via " + source);

  sendStateToApp();
}

// ═══════════════════════════════════════════════════════════════════
// COMMAND DECODER
// ═══════════════════════════════════════════════════════════════════
void decodeVC02Command(uint16_t cmd)
{
  Serial.print(F("🎤 Voice CMD: 0x"));
  Serial.println(cmd, HEX);

  switch (cmd)
  {
  case CMD_WAKEUP:
    Serial.println(F("   Wake word detected"));
    break;
  case CMD_EMERGENCY:
    triggerEmergency("voice");
    break;
  case CMD_CALL_NURSE:
    callNurse("voice");
    break;
  case CMD_LIGHT_ON:
    setLight(true, "voice");
    break;
  case CMD_LIGHT_OFF:
    setLight(false, "voice");
    break;
  case CMD_FAN_ON:
    setFan(true, "voice");
    break;
  case CMD_FAN_OFF:
    setFan(false, "voice");
    break;
  default:
    Serial.print(F("   Unknown: 0x"));
    Serial.println(cmd, HEX);
    break;
  }
}

// ═══════════════════════════════════════════════════════════════════
// COMMAND PROCESSOR
// ═══════════════════════════════════════════════════════════════════
void processVC02Commands()
{
  if (VC02Serial.available() > 0)
  {
    byte highByte = VC02Serial.read();

    unsigned long t = millis();
    while (VC02Serial.available() == 0)
    {
      if (millis() - t > 50)
        return;
    }

    byte lowByte = VC02Serial.read();
    vc02ReceivedValue = (highByte << 8) | lowByte;

    Serial.print(F("Received HEX: 0x"));
    Serial.println(vc02ReceivedValue, HEX);

    decodeVC02Command(vc02ReceivedValue);
    vc02ReceivedValue = 0;

    while (VC02Serial.available())
      VC02Serial.read();
  }
}

#endif