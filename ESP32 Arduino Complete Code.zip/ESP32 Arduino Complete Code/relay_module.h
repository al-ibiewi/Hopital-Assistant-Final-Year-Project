#ifndef RELAY_MODULE_H
#define RELAY_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "state.h"

// Forward declaration
void sendStateToApp();

// Non-blocking buzzer runtime state
bool buzzerAlertActive = false;
bool buzzerOutputHigh = false;
unsigned long buzzerPhaseStartedAt = 0;
int buzzerBeepCyclesDone = 0;

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setupPins()
{
  pinMode(RELAY_LIGHT, OUTPUT);
  pinMode(RELAY_FAN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(SWITCH_LIGHT, INPUT);
  pinMode(SWITCH_FAN, INPUT);

  digitalWrite(RELAY_LIGHT, LOW);
  digitalWrite(RELAY_FAN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  Serial.println(F("✓ Pins initialized"));
}

// ═══════════════════════════════════════════════════════════════════
// LIGHT CONTROL
// ═══════════════════════════════════════════════════════════════════
void setLight(bool on, String source)
{
  state.lightOn = on;
  state.lastCommand = on ? "LIGHT_ON" : "LIGHT_OFF";
  state.lastSource = source;

  digitalWrite(RELAY_LIGHT, on ? HIGH : LOW);

  Serial.print(F("💡 Light "));
  Serial.print(on ? F("ON") : F("OFF"));
  Serial.print(F(" [Source: "));
  Serial.print(source);
  Serial.println(F("]"));

  logEvent(String("Light ") + (on ? "ON" : "OFF") + " via " + source);
  sendStateToApp();
}

// ═══════════════════════════════════════════════════════════════════
// FAN CONTROL
// ═══════════════════════════════════════════════════════════════════
void setFan(bool on, String source)
{
  state.fanOn = on;
  state.lastCommand = on ? "FAN_ON" : "FAN_OFF";
  state.lastSource = source;

  digitalWrite(RELAY_FAN, on ? HIGH : LOW);

  Serial.print(F("🌀 Fan "));
  Serial.print(on ? F("ON") : F("OFF"));
  Serial.print(F(" [Source: "));
  Serial.print(source);
  Serial.println(F("]"));

  logEvent(String("Fan ") + (on ? "ON" : "OFF") + " via " + source);
  sendStateToApp();
}

// ═══════════════════════════════════════════════════════════════════
// BUZZER ALARM
// ═══════════════════════════════════════════════════════════════════
void triggerBuzzer()
{
  buzzerAlertActive = true;
  buzzerOutputHigh = true;
  buzzerPhaseStartedAt = millis();
  buzzerBeepCyclesDone = 0;

  digitalWrite(BUZZER_PIN, HIGH);
  Serial.println(F("🔔 Buzzer alarm started (non-blocking)"));
  logEvent("Buzzer started");
}

void stopBuzzer()
{
  if (!buzzerAlertActive && !buzzerOutputHigh)
  {
    return;
  }

  buzzerAlertActive = false;
  buzzerOutputHigh = false;
  buzzerBeepCyclesDone = 0;
  digitalWrite(BUZZER_PIN, LOW);
  Serial.println(F("🔔 Buzzer alarm stopped"));
  logEvent("Buzzer stopped");
}

void updateBuzzer()
{
  if (!buzzerAlertActive)
  {
    return;
  }

  unsigned long now = millis();

  if (buzzerOutputHigh)
  {
    if (now - buzzerPhaseStartedAt >= BUZZER_BEEP_DURATION)
    {
      digitalWrite(BUZZER_PIN, LOW);
      buzzerOutputHigh = false;
      buzzerPhaseStartedAt = now;
      buzzerBeepCyclesDone++;

      Serial.print(F("   BEEP "));
      Serial.print(buzzerBeepCyclesDone);
      Serial.print(F("/"));
      Serial.println(BUZZER_BEEP_COUNT);

      if (buzzerBeepCyclesDone >= BUZZER_BEEP_COUNT)
      {
        buzzerAlertActive = false;
        Serial.println(F("🔔 Buzzer alarm completed"));
        logEvent("Buzzer completed");
      }
    }
  }
  else
  {
    if (buzzerBeepCyclesDone < BUZZER_BEEP_COUNT &&
        now - buzzerPhaseStartedAt >= BUZZER_BEEP_PAUSE)
    {
      digitalWrite(BUZZER_PIN, HIGH);
      buzzerOutputHigh = true;
      buzzerPhaseStartedAt = now;
    }
  }
}

#endif