 #ifndef CONFIG_H
#define CONFIG_H

// ═══════════════════════════════════════════════════════════════════
// PIN DEFINITIONS
// ═══════════════════════════════════════════════════════════════════
#define VC02_RX_PIN     12
#define VC02_TX_PIN     14
#define SIM800_RX_PIN   26
#define SIM800_TX_PIN   27
#define RELAY_LIGHT     32
#define RELAY_FAN       33
#define BUZZER_PIN      25
#define SWITCH_LIGHT    34
#define SWITCH_FAN      35

// ═══════════════════════════════════════════════════════════════════
// BLE CONFIGURATION
// ═══════════════════════════════════════════════════════════════════
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"
#define DEVICE_NAME         "HospitalAssistant"

// ═══════════════════════════════════════════════════════════════════
// VC-02 COMMAND CODES
// ═══════════════════════════════════════════════════════════════════
#define CMD_WAKEUP      0xAA00
#define CMD_EMERGENCY   0xAA01
#define CMD_CALL_NURSE  0xAA02
#define CMD_LIGHT_ON    0xAB11
#define CMD_LIGHT_OFF   0xAB12
#define CMD_FAN_ON      0xFF11
#define CMD_FAN_OFF     0xFF12

// ═══════════════════════════════════════════════════════════════════
// TIMING CONSTANTS
// ═══════════════════════════════════════════════════════════════════
#define BUZZER_BEEP_DURATION  2000  // 2 seconds per beep
#define BUZZER_BEEP_PAUSE     500   // 0.5 second pause between beeps
#define BUZZER_BEEP_COUNT     3     // Number of beeps
#define DEBOUNCE_DELAY        50    // Switch debounce delay
#define NET_CHECK_INTERVAL    15000 // Network check every 15 seconds

// ═══════════════════════════════════════════════════════════════════
// DEFAULT CONFIGURATION (can be updated via app)
// ═══════════════════════════════════════════════════════════════════
#define DEFAULT_NURSE_PHONE   "+2348154686447"
#define DEFAULT_DOCTOR_PHONE  "+2348154686447"
#define DEFAULT_PATIENT_BED   "Bed 1"

#endif