#ifndef SIM800_MODULE_H
#define SIM800_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "state.h"

// ═══════════════════════════════════════════════════════════════════
// UART OBJECT
// ═══════════════════════════════════════════════════════════════════
HardwareSerial SIM800Serial(2);

String waitForSIMResponse(unsigned long timeoutMs)
{
  String response = "";
  unsigned long start = millis();

  while (millis() - start < timeoutMs)
  {
    while (SIM800Serial.available())
    {
      char c = (char)SIM800Serial.read();
      response += c;
    }

    if (response.indexOf("OK") >= 0 ||
        response.indexOf("ERROR") >= 0 ||
        response.indexOf(">") >= 0 ||
        response.indexOf("+CMGS:") >= 0)
    {
      break;
    }
  }

  if (response.length() > 0)
  {
    Serial.print(response);
  }

  return response;
}

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setupSIM800()
{
  SIM800Serial.begin(9600, SERIAL_8N1, SIM800_RX_PIN, SIM800_TX_PIN);
  delay(100);

  Serial.println(F("→ SIM800L basic setup..."));
  SIM800Serial.println("AT");
  delay(500);
  SIM800Serial.println("AT+CMGF=1");
  delay(500);
  SIM800Serial.println("AT+CSCS=\"GSM\"");
  delay(500);

  while (SIM800Serial.available())
    SIM800Serial.read();

  Serial.println(F("✓ SIM800L setup done - connecting in background"));
}

// ═══════════════════════════════════════════════════════════════════
// AT COMMAND SENDER
// ═══════════════════════════════════════════════════════════════════
void sendATCommand(String command, int timeout)
{
  Serial.print(F("AT>> "));
  Serial.println(command);
  SIM800Serial.println(command);

  long int time = millis();
  while ((time + timeout) > millis())
  {
    while (SIM800Serial.available())
    {
      Serial.write(SIM800Serial.read());
    }
  }
  Serial.println();
}

// ═══════════════════════════════════════════════════════════════════
// SMS SENDER
// ═══════════════════════════════════════════════════════════════════
bool sendSMS(String phoneNumber, String message)
{
  if (!netState.networkReady)
  {
    Serial.println(F("⚠️ SMS aborted: network not ready"));
    logEvent("SMS aborted: network not ready");
    return false;
  }

  const int maxRetries = 3;

  for (int attempt = 1; attempt <= maxRetries; attempt++)
  {
    Serial.println(F("\n→ Sending SMS..."));
    Serial.print(F("→ Attempt: "));
    Serial.print(attempt);
    Serial.print(F("/"));
    Serial.println(maxRetries);
    Serial.print(F("→ To: "));
    Serial.println(phoneNumber);

    while (SIM800Serial.available())
    {
      SIM800Serial.read();
    }

    SIM800Serial.println("AT+CMGF=1");
    String modeResp = waitForSIMResponse(3000);
    if (modeResp.indexOf("OK") < 0)
    {
      Serial.println(F("⚠️ CMGF command failed"));
      delay(500);
      continue;
    }

    String cmd = "AT+CMGS=\"" + phoneNumber + "\"";
    SIM800Serial.println(cmd);
    String promptResp = waitForSIMResponse(4000);
    if (promptResp.indexOf(">") < 0)
    {
      Serial.println(F("⚠️ SMS prompt not received"));
      delay(500);
      continue;
    }

    SIM800Serial.print(message);
    SIM800Serial.write(26);
    String submitResp = waitForSIMResponse(15000);

    if (submitResp.indexOf("+CMGS:") >= 0 && submitResp.indexOf("ERROR") < 0)
    {
      Serial.println(F("→ SMS sent successfully\n"));
      logEvent("SMS sent to " + phoneNumber);
      return true;
    }

    Serial.println(F("⚠️ SMS send failed, retrying..."));
    delay(1000);
  }

  Serial.println(F("❌ SMS failed after retries\n"));
  logEvent("SMS failed to " + phoneNumber);
  return false;
}

// ═══════════════════════════════════════════════════════════════════
// BACKGROUND NETWORK CHECK
// ═══════════════════════════════════════════════════════════════════
void checkNetworkStatus()
{
  if (millis() - netState.lastCheck < NET_CHECK_INTERVAL)
    return;
  netState.lastCheck = millis();

  Serial.println(F("📡 Checking network..."));

  SIM800Serial.println("AT+CREG?");
  delay(1000);

  String response = "";
  while (SIM800Serial.available())
  {
    response += (char)SIM800Serial.read();
  }

  bool wasReady = netState.networkReady;
  bool nowReady = (response.indexOf("+CREG: 0,1") >= 0 ||
                   response.indexOf("+CREG: 0,5") >= 0);
  netState.networkReady = nowReady;

  if (nowReady)
  {
    if (!wasReady)
    {
      Serial.println(F("✅ Network registered! SMS alerts active."));
      logEvent("Network registered");
    }
    else
    {
      Serial.println(F("✅ Network OK"));
    }

    SIM800Serial.println("AT+CSQ");
    delay(500);
    while (SIM800Serial.available())
      Serial.write(SIM800Serial.read());
  }
  else
  {
    if (wasReady)
    {
      Serial.println(F("⚠️ Network lost"));
      logEvent("Network lost");
    }
    Serial.println(F("⏳ Network not ready - retry in 15s"));
  }
}

// ═══════════════════════════════════════════════════════════════════
// FORWARD SIM800L RESPONSES TO SERIAL
// ═══════════════════════════════════════════════════════════════════
void processSIM800Responses()
{
  while (SIM800Serial.available())
  {
    Serial.write(SIM800Serial.read());
  }
}

#endif