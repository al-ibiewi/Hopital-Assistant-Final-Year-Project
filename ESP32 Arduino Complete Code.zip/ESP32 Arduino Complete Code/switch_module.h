#ifndef SWITCH_MODULE_H
#define SWITCH_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "state.h"
#include "relay_module.h"

// ═══════════════════════════════════════════════════════════════════
// SWITCH STATE
// ═══════════════════════════════════════════════════════════════════
bool lastLightSwitchState = HIGH;
bool lastFanSwitchState = HIGH;
bool stableLightSwitchState = HIGH;
bool stableFanSwitchState = HIGH;
bool lightPressedLevel = LOW;
bool fanPressedLevel = LOW;
unsigned long lastDebounceLight = 0;
unsigned long lastDebounceFan = 0;

void initPhysicalSwitches()
{
  // Auto-detect expected press level from idle state to support
  // both pull-up and pull-down hardware wiring.
  stableLightSwitchState = digitalRead(SWITCH_LIGHT);
  lastLightSwitchState = stableLightSwitchState;
  lightPressedLevel = (stableLightSwitchState == HIGH) ? LOW : HIGH;

  stableFanSwitchState = digitalRead(SWITCH_FAN);
  lastFanSwitchState = stableFanSwitchState;
  fanPressedLevel = (stableFanSwitchState == HIGH) ? LOW : HIGH;

  Serial.print(F("Switch init - LIGHT idle="));
  Serial.print(stableLightSwitchState);
  Serial.print(F(" pressed="));
  Serial.println(lightPressedLevel);

  Serial.print(F("Switch init - FAN idle="));
  Serial.print(stableFanSwitchState);
  Serial.print(F(" pressed="));
  Serial.println(fanPressedLevel);
}

// ═══════════════════════════════════════════════════════════════════
// PHYSICAL SWITCH HANDLER
// ═══════════════════════════════════════════════════════════════════
void checkPhysicalSwitches()
{
  // Light Switch
  bool lightReading = digitalRead(SWITCH_LIGHT);
  if (lightReading != lastLightSwitchState)
  {
    lastDebounceLight = millis();
  }
  if ((millis() - lastDebounceLight) > DEBOUNCE_DELAY)
  {
    if (lightReading != stableLightSwitchState)
    {
      stableLightSwitchState = lightReading;
      if (stableLightSwitchState == lightPressedLevel)
      {
        setLight(!state.lightOn, "switch");
      }
    }
  }
  lastLightSwitchState = lightReading;

  // Fan Switch
  bool fanReading = digitalRead(SWITCH_FAN);
  if (fanReading != lastFanSwitchState)
  {
    lastDebounceFan = millis();
  }
  if ((millis() - lastDebounceFan) > DEBOUNCE_DELAY)
  {
    if (fanReading != stableFanSwitchState)
    {
      stableFanSwitchState = fanReading;
      if (stableFanSwitchState == fanPressedLevel)
      {
        setFan(!state.fanOn, "switch");
      }
    }
  }
  lastFanSwitchState = fanReading;
}

#endif