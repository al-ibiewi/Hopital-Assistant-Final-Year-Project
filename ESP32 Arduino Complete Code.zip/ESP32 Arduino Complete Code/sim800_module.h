#ifndef SIM800_MODULE_H
#define SIM800_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "state.h"

void sendStateToApp();
String waitForSIMResponse(unsigned long timeoutMs);
String waitForSMSSendResult(unsigned long timeoutMs);

// ═══════════════════════════════════════════════════════════════════
// UART OBJECT
// ═══════════════════════════════════════════════════════════════════
HardwareSerial SIM800Serial(2);
portMUX_TYPE simTransactionMux = portMUX_INITIALIZER_UNLOCKED;
volatile bool simTransactionActive = false;

bool beginSIMTransaction(unsigned long timeoutMs)
{
  unsigned long startedAt = millis();

  while (true)
  {
    bool acquired = false;

    portENTER_CRITICAL(&simTransactionMux);
    if (!simTransactionActive)
    {
      simTransactionActive = true;
      acquired = true;
    }
    portEXIT_CRITICAL(&simTransactionMux);

    if (acquired)
    {
      return true;
    }

    if (timeoutMs > 0 && (millis() - startedAt) >= timeoutMs)
    {
      return false;
    }

    delay(1);
  }
}

void endSIMTransaction()
{
  portENTER_CRITICAL(&simTransactionMux);
  simTransactionActive = false;
  portEXIT_CRITICAL(&simTransactionMux);
}

bool isSIMTransactionActive()
{
  bool active;

  portENTER_CRITICAL(&simTransactionMux);
  active = simTransactionActive;
  portEXIT_CRITICAL(&simTransactionMux);

  return active;
}

String normalizePhoneNumber(const String &raw)
{
  String trimmed = raw;
  trimmed.trim();

  String result = "";
  bool sawDigit = false;

  for (int i = 0; i < (int)trimmed.length(); i++)
  {
    char ch = trimmed[i];

    if (ch == '+' && result.length() == 0)
    {
      result += ch;
      continue;
    }

    if (isDigit(ch))
    {
      result += ch;
      sawDigit = true;
      continue;
    }

    if (sawDigit)
    {
      break;
    }
  }

  if (!sawDigit)
  {
    return "";
  }

  return result;
}

String buildSafeSMSMessage(const String &raw)
{
  String safe = "";

  for (int i = 0; i < (int)raw.length(); i++)
  {
    char ch = raw[i];

    if (ch == '\r')
    {
      continue;
    }

    if (ch == '\n')
    {
      safe += "\r\n";
      continue;
    }

    if (ch >= 32 && ch <= 126)
    {
      safe += ch;
    }
    else
    {
      safe += ' ';
    }

    if (safe.length() >= 320)
    {
      break;
    }
  }

  safe.trim();
  if (safe.length() == 0)
  {
    safe = "Hospital Assistant alert";
  }

  return safe;
}

String runSIMCommand(const String &command, unsigned long timeoutMs)
{
  while (SIM800Serial.available())
  {
    SIM800Serial.read();
  }

  SIM800Serial.println(command);
  return waitForSIMResponse(timeoutMs);
}

int parseRegistrationStat(const String &response, const String &prefix)
{
  int searchFrom = 0;

  while (searchFrom >= 0 && searchFrom < (int)response.length())
  {
    int idx = response.indexOf(prefix, searchFrom);
    if (idx < 0)
    {
      return -1;
    }

    int comma = response.indexOf(',', idx + prefix.length());
    if (comma < 0)
    {
      searchFrom = idx + prefix.length();
      continue;
    }

    int statPos = comma + 1;
    while (statPos < (int)response.length() &&
           (response[statPos] == ' ' || response[statPos] == '\t'))
    {
      statPos++;
    }

    if (statPos < (int)response.length() && isDigit(response[statPos]))
    {
      return response[statPos] - '0';
    }

    searchFrom = idx + prefix.length();
  }

  return -1;
}

bool isRegisteredStat(int stat)
{
  return (stat == 1 || stat == 5);
}

int parseCSQValue(const String &response)
{
  int idx = response.indexOf("+CSQ:");
  if (idx < 0)
  {
    return -1;
  }

  int colon = response.indexOf(':', idx);
  if (colon < 0)
  {
    return -1;
  }

  int pos = colon + 1;
  while (pos < (int)response.length() &&
         (response[pos] == ' ' || response[pos] == '\t'))
  {
    pos++;
  }

  String digits = "";
  while (pos < (int)response.length() && isDigit(response[pos]))
  {
    digits += response[pos];
    pos++;
  }

  if (digits.length() == 0)
  {
    return -1;
  }

  return digits.toInt();
}

bool refreshNetworkState(bool verbose)
{
  String cregResp = runSIMCommand("AT+CREG?", 2500);
  String cgregResp = runSIMCommand("AT+CGREG?", 2500);
  String csqResp = runSIMCommand("AT+CSQ", 2000);

  int cregStat = parseRegistrationStat(cregResp, "+CREG:");
  int cgregStat = parseRegistrationStat(cgregResp, "+CGREG:");
  int csq = parseCSQValue(csqResp);

  netState.simReady = (cregResp.indexOf("OK") >= 0 || cgregResp.indexOf("OK") >= 0);
  bool registered = (isRegisteredStat(cregStat) || isRegisteredStat(cgregStat));
  bool hasUsableSignal = (csq >= 0 && csq < 99);
  bool fallbackRegistered = (!registered &&
                             hasUsableSignal &&
                             netState.simReady &&
                             cregStat < 0 &&
                             cgregStat < 0);
  netState.networkReady = (registered || fallbackRegistered);

  if (verbose)
  {
    Serial.print(F("📶 CREG stat="));
    Serial.print(cregStat);
    Serial.print(F(" | CGREG stat="));
    Serial.print(cgregStat);
    Serial.print(F(" | CSQ="));
    Serial.println(csq);
  }

  return netState.networkReady;
}

String waitForSIMResponse(unsigned long timeoutMs)
{
  String response = "";
  unsigned long start = millis();

  while (millis() - start < timeoutMs)
  {
    while (SIM800Serial.available())
    {
      char c = (char)SIM800Serial.read();
      response += c;
    }

    if (response.indexOf("OK") >= 0 ||
        response.indexOf("ERROR") >= 0 ||
        response.indexOf(">") >= 0 ||
        response.indexOf("+CMGS:") >= 0)
    {
      break;
    }
  }

  if (response.length() > 0)
  {
    Serial.print(response);
  }

  return response;
}

String waitForSMSSendResult(unsigned long timeoutMs)
{
  String response = "";
  unsigned long start = millis();

  while (millis() - start < timeoutMs)
  {
    while (SIM800Serial.available())
    {
      char c = (char)SIM800Serial.read();
      response += c;
    }

    if (response.indexOf("+CMGS:") >= 0 ||
        response.indexOf("+CMS ERROR:") >= 0 ||
        response.indexOf("+CME ERROR:") >= 0)
    {
      break;
    }

    // Generic ERROR handling for modules that do not return +CMS/+CME.
    if (response.indexOf("ERROR") >= 0)
    {
      break;
    }
  }

  if (response.length() > 0)
  {
    Serial.print(response);
  }

  return response;
}

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setupSIM800()
{
  SIM800Serial.begin(9600, SERIAL_8N1, SIM800_RX_PIN, SIM800_TX_PIN);
  delay(100);

  Serial.println(F("→ SIM800L basic setup..."));
  SIM800Serial.println("AT");
  delay(500);
  SIM800Serial.println("AT+CMGF=1");
  delay(500);
  SIM800Serial.println("AT+CSCS=\"GSM\"");
  delay(500);

  while (SIM800Serial.available())
    SIM800Serial.read();

  Serial.println(F("✓ SIM800L setup done - connecting in background"));
}

// ═══════════════════════════════════════════════════════════════════
// AT COMMAND SENDER
// ═══════════════════════════════════════════════════════════════════
void sendATCommand(String command, int timeout)
{
  Serial.print(F("AT>> "));
  Serial.println(command);
  SIM800Serial.println(command);

  long int time = millis();
  while ((time + timeout) > millis())
  {
    while (SIM800Serial.available())
    {
      Serial.write(SIM800Serial.read());
    }
  }
  Serial.println();
}

// ═══════════════════════════════════════════════════════════════════
// SMS SENDER
// ═══════════════════════════════════════════════════════════════════
bool sendSMS(String phoneNumber, String message)
{
  String dialNumber = normalizePhoneNumber(phoneNumber);
  String safeMessage = buildSafeSMSMessage(message);
  if (dialNumber.length() == 0)
  {
    Serial.print(F("[SMS] Invalid phone value: "));
    Serial.println(phoneNumber);
    logEvent("SMS aborted: invalid phone value");
    return false;
  }

  if (!beginSIMTransaction(3000))
  {
    Serial.println(F("[SMS] SIM busy, cannot start transaction"));
    logEvent("SMS aborted: SIM busy");
    return false;
  }

  if (!netState.networkReady)
  {
    Serial.println(F("⚠️ Cached network state is not ready - rechecking..."));
    refreshNetworkState(true);
    sendStateToApp();

    if (!netState.networkReady)
    {
      Serial.println(F("⚠️ Network still not confirmed. Trying SMS anyway..."));
      logEvent("SMS retry path: network uncertain");
    }
  }

  const int maxRetries = 2;
  bool sent = false;

  for (int attempt = 1; attempt <= maxRetries; attempt++)
  {
    Serial.println(F("\n→ Sending SMS..."));
    Serial.print(F("→ Attempt: "));
    Serial.print(attempt);
    Serial.print(F("/"));
    Serial.println(maxRetries);
    Serial.print(F("→ To: "));
    Serial.println(dialNumber);

    while (SIM800Serial.available())
    {
      SIM800Serial.read();
    }

    String modeResp = runSIMCommand("AT+CMGF=1", 3000);
    if (modeResp.indexOf("OK") < 0)
    {
      Serial.println(F("⚠️ CMGF command failed"));
      delay(500);
      continue;
    }

    String charsetResp = runSIMCommand("AT+CSCS=\"GSM\"", 3000);
    if (charsetResp.indexOf("OK") < 0)
    {
      Serial.println(F("⚠️ CSCS command failed"));
      delay(500);
      continue;
    }

    String csmpResp = runSIMCommand("AT+CSMP=17,167,0,0", 3000);
    if (csmpResp.indexOf("OK") < 0)
    {
      Serial.println(F("⚠️ CSMP command failed"));
      delay(500);
      continue;
    }

    String csdhResp = runSIMCommand("AT+CSDH=0", 3000);
    if (csdhResp.indexOf("OK") < 0)
    {
      Serial.println(F("⚠️ CSDH command failed"));
      delay(500);
      continue;
    }

    String cmd = "AT+CMGS=\"" + dialNumber + "\"";
    SIM800Serial.println(cmd);
    String promptResp = waitForSIMResponse(4000);
    if (promptResp.indexOf(">") < 0)
    {
      Serial.println(F("⚠️ SMS prompt not received"));
      delay(500);
      continue;
    }

    SIM800Serial.print(safeMessage);
    SIM800Serial.write(26);
    String submitResp = waitForSMSSendResult(30000);

    if (submitResp.indexOf("+CMGS:") >= 0)
    {
      Serial.println(F("→ SMS sent successfully\n"));
      logEvent("SMS sent to " + dialNumber);
      sent = true;
      break;
    }

    bool hardError = (submitResp.indexOf("+CMS ERROR:") >= 0 ||
                      submitResp.indexOf("+CME ERROR:") >= 0 ||
                      submitResp.indexOf("ERROR") >= 0);

    // Some networks delay/drop +CMGS URC even after modem accepted submission.
    // If no explicit error is present, do not retry to avoid duplicate SMS.
    if (!hardError && submitResp.indexOf("OK") >= 0)
    {
      Serial.println(F("⚠️ SMS submitted but +CMGS not observed; treating as sent to avoid duplicate"));
      logEvent("SMS submit unconfirmed to " + dialNumber);
      sent = true;
      break;
    }

    Serial.println(F("⚠️ SMS send failed, retrying..."));
    delay(1000);
  }

  if (!sent)
  {
    Serial.println(F("❌ SMS failed after retries\n"));
    logEvent("SMS failed to " + dialNumber);
  }

  endSIMTransaction();
  return sent;
}

// ═══════════════════════════════════════════════════════════════════
// BACKGROUND NETWORK CHECK
// ═══════════════════════════════════════════════════════════════════
void checkNetworkStatus()
{
  if (netState.lastCheck != 0 && (millis() - netState.lastCheck) < NET_CHECK_INTERVAL)
    return;

  if (!beginSIMTransaction(10))
  {
    return;
  }

  netState.lastCheck = millis();

  Serial.println(F("📡 Checking network..."));

  bool wasReady = netState.networkReady;
  bool wasSimReady = netState.simReady;
  bool nowReady = refreshNetworkState(true);
  bool networkStateChanged = (wasReady != nowReady);
  bool simStateChanged = (wasSimReady != netState.simReady);

  if (!netState.simReady)
  {
    Serial.println(F("⚠️ SIM800L not responding to AT registration checks"));
  }

  if (nowReady)
  {
    if (!wasReady)
    {
      Serial.println(F("✅ Network registered! SMS alerts active."));
      logEvent("Network registered");
    }
    else
    {
      Serial.println(F("✅ Network OK"));
    }
  }
  else
  {
    if (wasReady)
    {
      Serial.println(F("⚠️ Network lost"));
      logEvent("Network lost");
    }
    Serial.println(F("⏳ Network not ready - retry in 15s"));
  }

  if (networkStateChanged || simStateChanged)
  {
    Serial.println(F("📡 Pushing network state to app"));
    sendStateToApp();
  }

  endSIMTransaction();
}

// ═══════════════════════════════════════════════════════════════════
// FORWARD SIM800L RESPONSES TO SERIAL
// ═══════════════════════════════════════════════════════════════════
void processSIM800Responses()
{
  if (isSIMTransactionActive())
  {
    return;
  }

  while (SIM800Serial.available())
  {
    Serial.write(SIM800Serial.read());
  }
}

#endif