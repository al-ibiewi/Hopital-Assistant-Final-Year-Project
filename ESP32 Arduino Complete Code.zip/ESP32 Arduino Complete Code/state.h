#ifndef STATE_H
#define STATE_H

#include <Arduino.h>

// ═══════════════════════════════════════════════════════════════════
// DEVICE STATE (Single source of truth)
// ═══════════════════════════════════════════════════════════════════
struct DeviceState
{
  bool lightOn = false;
  bool fanOn = false;
  bool emergencyActive = false;
  bool nurseCallActive = false;
  String lastCommand = "none";
  String lastSource = "none";
};

// ═══════════════════════════════════════════════════════════════════
// NETWORK STATE
// ═══════════════════════════════════════════════════════════════════
struct NetworkState
{
  bool networkReady = false;
  bool simReady = false;
  unsigned long lastCheck = 0;
};

// ═══════════════════════════════════════════════════════════════════
// EVENT LOG STATE
// ═══════════════════════════════════════════════════════════════════
const int EVENT_LOG_CAPACITY = 25;

struct EventLogState
{
  String entries[EVENT_LOG_CAPACITY];
  int head = 0;
  int count = 0;
};

// ═══════════════════════════════════════════════════════════════════
// GLOBAL STATE INSTANCES
// ═══════════════════════════════════════════════════════════════════
extern DeviceState state;
extern NetworkState netState;
extern EventLogState eventLog;

// ═══════════════════════════════════════════════════════════════════
// CONFIGURATION (updatable via app)
// ═══════════════════════════════════════════════════════════════════
extern String NURSE_PHONE;
extern String DOCTOR_PHONE;
extern String PATIENT_BED;

// ═══════════════════════════════════════════════════════════════════
// SHARED SERVICES
// ═══════════════════════════════════════════════════════════════════
void setupPersistentSettings();
void persistAllSettings();
bool verifySettingsInNVS();
void logEvent(const String &eventText);
String getEventLogDump();

#endif