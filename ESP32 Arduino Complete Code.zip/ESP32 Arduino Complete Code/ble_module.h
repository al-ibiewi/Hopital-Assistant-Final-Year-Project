#ifndef BLE_MODULE_H
#define BLE_MODULE_H

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include "config.h"
#include "state.h"
#include "relay_module.h"
#include "vc02_module.h"

// ═══════════════════════════════════════════════════════════════════
// BLE OBJECTS
// ═══════════════════════════════════════════════════════════════════
BLEServer *pServer = nullptr;
BLECharacteristic *pCharacteristic = nullptr;
bool deviceConnected = false;
bool oldDeviceConnected = false;

void sendBleMessage(const String &message)
{
  if (!deviceConnected)
    return;

  pCharacteristic->setValue(message.c_str());
  pCharacteristic->notify();
}

void sendAppAck(bool ok, const String &command, const String &detail)
{
  String ack = String(ok ? "ACK:" : "NACK:") + command;
  if (detail.length() > 0)
  {
    ack += ",";
    ack += detail;
  }

  sendBleMessage(ack);
}

// ═══════════════════════════════════════════════════════════════════
// SEND STATE TO APP
// ═══════════════════════════════════════════════════════════════════
void sendStateToApp()
{
  if (!deviceConnected)
    return;

  String stateMsg =
      "LIGHT:" + String(state.lightOn ? "1" : "0") +
      ",FAN:" + String(state.fanOn ? "1" : "0") +
      ",EMERGENCY:" + String(state.emergencyActive ? "1" : "0") +
      ",NURSECALL:" + String(state.nurseCallActive ? "1" : "0") +
      ",NETWORK:" + String(netState.networkReady ? "1" : "0") +
      ",SOURCE:" + state.lastSource;

  sendBleMessage(stateMsg);

  Serial.print(F("📡 State: "));
  Serial.println(stateMsg);
}

// ═══════════════════════════════════════════════════════════════════
// PROCESS APP COMMANDS
// ═══════════════════════════════════════════════════════════════════
void processAppCommand(String command)
{
  Serial.print(F("📱 App CMD: "));
  Serial.println(command);

  bool recognized = true;
  bool ok = true;
  String detail = "";

  if (command == "LIGHT_ON")
  {
    setLight(true, "app");
  }
  else if (command == "LIGHT_OFF")
  {
    setLight(false, "app");
  }
  else if (command == "FAN_ON")
  {
    setFan(true, "app");
  }
  else if (command == "FAN_OFF")
  {
    setFan(false, "app");
  }
  else if (command == "EMERGENCY")
  {
    triggerEmergency("app");
  }
  else if (command == "EMERGENCY_CLEAR")
  {
    clearEmergency("app");
  }
  else if (command == "CALL_NURSE")
  {
    callNurse("app");
  }
  else if (command == "ACK_NURSE")
  {
    acknowledgeNurseCall("app");
  }
  else if (command == "GET_STATE")
  {
    sendStateToApp();
  }
  else if (command == "GET_LOG")
  {
    String logs = getEventLogDump();
    if (logs.length() > 300)
    {
      logs = logs.substring(logs.length() - 300);
    }
    sendBleMessage("LOG:" + logs);
  }
  else if (command == "GET_CONFIG")
  {
    String cfg = "BED:" + PATIENT_BED + ",NURSE:" + NURSE_PHONE + ",DOCTOR:" + DOCTOR_PHONE;
    if (cfg.length() > 250)
    {
      cfg = cfg.substring(0, 250);
    }
    sendBleMessage("CFG:" + cfg);
  }

  // Settings sync from app
  else if (command.startsWith("SET_BED:"))
  {
    PATIENT_BED = command.substring(8);
    persistAllSettings();
    Serial.print(F("✓ Bed: "));
    Serial.println(PATIENT_BED);
    detail = "BED_SAVED";
    logEvent("Config updated: bed=" + PATIENT_BED);
    sendStateToApp();
  }
  else if (command.startsWith("SET_NURSE:"))
  {
    NURSE_PHONE = command.substring(10);
    persistAllSettings();
    Serial.print(F("✓ Nurse: "));
    Serial.println(NURSE_PHONE);
    detail = "NURSE_SAVED";
    logEvent("Config updated: nurse phone");
  }
  else if (command.startsWith("SET_DOCTOR:"))
  {
    DOCTOR_PHONE = command.substring(11);
    persistAllSettings();
    Serial.print(F("✓ Doctor: "));
    Serial.println(DOCTOR_PHONE);
    detail = "DOCTOR_SAVED";
    logEvent("Config updated: doctor phone");
  }
  else
  {
    recognized = false;
    ok = false;
    detail = "UNKNOWN_COMMAND";
  }

  if (recognized)
  {
    logEvent("BLE command: " + command);
  }

  sendAppAck(ok, command, detail);
}

// ═══════════════════════════════════════════════════════════════════
// BLE CALLBACKS
// ═══════════════════════════════════════════════════════════════════
class ServerCallbacks : public BLEServerCallbacks
{
  void onConnect(BLEServer *pServer)
  {
    deviceConnected = true;
    Serial.println(F("📱 App connected"));
    sendStateToApp();
  }
  void onDisconnect(BLEServer *pServer)
  {
    deviceConnected = false;
    Serial.println(F("📱 App disconnected"));
  }
};

class CharacteristicCallbacks : public BLECharacteristicCallbacks
{
  void onWrite(BLECharacteristic *pCharacteristic)
  {
    String rxValue = pCharacteristic->getValue().c_str();
    if (rxValue.length() > 0)
    {
      processAppCommand(rxValue);
    }
  }
};

// ═══════════════════════════════════════════════════════════════════
// BLE SETUP
// ═══════════════════════════════════════════════════════════════════
void setupBLE()
{
  BLEDevice::init(DEVICE_NAME);
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  pCharacteristic = pService->createCharacteristic(
      CHARACTERISTIC_UUID,
      BLECharacteristic::PROPERTY_READ |
          BLECharacteristic::PROPERTY_WRITE |
          BLECharacteristic::PROPERTY_NOTIFY);

  pCharacteristic->addDescriptor(new BLE2902());
  pCharacteristic->setCallbacks(new CharacteristicCallbacks());

  pService->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println(F("✓ BLE initialized - HospitalAssistant"));
}

// ═══════════════════════════════════════════════════════════════════
// BLE RECONNECTION HANDLER
// ═══════════════════════════════════════════════════════════════════
void handleBLEReconnection()
{
  if (!deviceConnected && oldDeviceConnected)
  {
    delay(500);
    pServer->startAdvertising();
    Serial.println(F("📡 BLE advertising restarted"));
    oldDeviceConnected = deviceConnected;
  }
  if (deviceConnected && !oldDeviceConnected)
  {
    oldDeviceConnected = deviceConnected;
  }
}

#endif