#ifndef BLE_MODULE_H
#define BLE_MODULE_H

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include "config.h"
#include "state.h"
#include "relay_module.h"
#include "vc02_module.h"

// ═══════════════════════════════════════════════════════════════════
// BLE OBJECTS
// ═══════════════════════════════════════════════════════════════════
BLEServer *pServer = nullptr;
BLECharacteristic *pCharacteristic = nullptr;
bool deviceConnected = false;
bool oldDeviceConnected = false;

String bleRxBuffer = "";
unsigned long bleLastChunkAt = 0;
const unsigned long BLE_RX_FLUSH_MS = 120;
unsigned long bleLastStatePushAt = 0;
const unsigned long BLE_STATE_PUSH_INTERVAL = 5000;

void sendBleMessage(const String &message);
void processAppCommand(String command);
void processBleBufferedCommand(bool force = false);

String getCommandTag(const String &command)
{
  int colonIdx = command.indexOf(':');
  int equalsIdx = command.indexOf('=');

  int sepIdx = -1;
  if (colonIdx >= 0 && equalsIdx >= 0)
  {
    sepIdx = min(colonIdx, equalsIdx);
  }
  else if (colonIdx >= 0)
  {
    sepIdx = colonIdx;
  }
  else
  {
    sepIdx = equalsIdx;
  }

  String tag = (sepIdx >= 0) ? command.substring(0, sepIdx) : command;
  tag.trim();
  tag.toUpperCase();
  return tag;
}

String buildConfigPayload()
{
  String cfg = "BED:" + PATIENT_BED + ",NURSE:" + NURSE_PHONE + ",DOCTOR:" + DOCTOR_PHONE;
  if (cfg.length() > 250)
  {
    cfg = cfg.substring(0, 250);
  }
  return cfg;
}

void sendConfigToApp()
{
  sendBleMessage("CFG:" + buildConfigPayload());
}

String extractSettingValue(const String &command)
{
  int colonIdx = command.indexOf(':');
  int equalsIdx = command.indexOf('=');

  int sepIdx = -1;
  if (colonIdx >= 0 && equalsIdx >= 0)
  {
    sepIdx = min(colonIdx, equalsIdx);
  }
  else if (colonIdx >= 0)
  {
    sepIdx = colonIdx;
  }
  else
  {
    sepIdx = equalsIdx;
  }

  if (sepIdx < 0 || sepIdx + 1 >= (int)command.length())
  {
    return "";
  }

  String value = command.substring(sepIdx + 1);
  value.trim();
  return value;
}

String trimAtNextCommandToken(const String &raw)
{
  String value = raw;
  value.trim();

  if (value.length() == 0)
  {
    return value;
  }

  String upper = value;
  upper.toUpperCase();

  const char *tokens[] = {
      "SET_",
      "GET_",
      "LIGHT_",
      "FAN_",
      "EMERGENCY",
      "CALL_NURSE",
      "ACK_NURSE",
      "RESET_GSM",
      "VERIFY_CONFIG",
      "NURSE:",
      "DOCTOR:",
      "BED:"};

  int cut = -1;
  for (unsigned int i = 0; i < (sizeof(tokens) / sizeof(tokens[0])); i++)
  {
    int idx = upper.indexOf(tokens[i], 1);
    if (idx > 0 && (cut < 0 || idx < cut))
    {
      cut = idx;
    }
  }

  if (cut > 0)
  {
    value = value.substring(0, cut);
    value.trim();
  }

  return value;
}

String sanitizePhoneNumberValue(const String &raw)
{
  String value = trimAtNextCommandToken(raw);

  String result = "";
  bool sawDigit = false;

  for (int i = 0; i < (int)value.length(); i++)
  {
    char ch = value[i];

    if (ch == '+' && result.length() == 0)
    {
      result += ch;
      continue;
    }

    if (isDigit(ch))
    {
      result += ch;
      sawDigit = true;
      continue;
    }

    if (sawDigit)
    {
      break;
    }
  }

  if (!sawDigit)
  {
    return "";
  }

  return result;
}

void sendBleMessage(const String &message)
{
  if (!deviceConnected)
    return;

  pCharacteristic->setValue(message.c_str());
  pCharacteristic->notify();
}

void sendAppAck(bool ok, const String &command, const String &detail)
{
  String ack = String(ok ? "ACK:" : "NACK:") + command;
  if (detail.length() > 0)
  {
    ack += ",";
    ack += detail;
  }

  sendBleMessage(ack);
}

void processBleBufferedCommand(bool force)
{
  if (bleRxBuffer.length() == 0)
  {
    return;
  }

  if (!force && (millis() - bleLastChunkAt) < BLE_RX_FLUSH_MS)
  {
    return;
  }

  String cmd = bleRxBuffer;
  bleRxBuffer = "";
  cmd.trim();

  if (cmd.length() > 0)
  {
    processAppCommand(cmd);
  }
}

void sendEventLog()
{
  const int maxNotifyLength = 300;
  String body = "";

  if (eventLog.count == 0)
  {
    sendBleMessage("LOG:EMPTY");
    return;
  }

  // Include as many recent entries as possible, separated by newlines.
  for (int i = 0; i < eventLog.count; i++)
  {
    int idx = (eventLog.head - 1 - i + EVENT_LOG_CAPACITY) % EVENT_LOG_CAPACITY;
    String line = eventLog.entries[idx];
    String candidate = (body.length() == 0) ? line : (line + "\n" + body);

    if ((int)(4 + candidate.length()) > maxNotifyLength)
    {
      break;
    }

    body = candidate;
  }

  if (body.length() == 0)
  {
    body = "EMPTY";
  }

  sendBleMessage("LOG:" + body);
}

// ═══════════════════════════════════════════════════════════════════
// SEND STATE TO APP
// ═══════════════════════════════════════════════════════════════════
void sendStateToApp()
{
  if (!deviceConnected)
    return;

  String stateMsg =
      "LIGHT:" + String(state.lightOn ? "1" : "0") +
      ",FAN:" + String(state.fanOn ? "1" : "0") +
      ",EMERGENCY:" + String(state.emergencyActive ? "1" : "0") +
      ",NURSECALL:" + String(state.nurseCallActive ? "1" : "0") +
      ",NETWORK:" + String(netState.networkReady ? "1" : "0") +
      ",SOURCE:" + state.lastSource;

  sendBleMessage(stateMsg);

  Serial.print(F("📡 State: "));
  Serial.println(stateMsg);
}

// ═══════════════════════════════════════════════════════════════════
// PROCESS APP COMMANDS
// ═══════════════════════════════════════════════════════════════════
void processAppCommand(String command)
{
  command.trim();

  if (command.length() == 0)
  {
    sendAppAck(false, "EMPTY", "EMPTY_COMMAND");
    return;
  }

  String cmdUpper = command;
  cmdUpper.toUpperCase();
  String cmdTag = getCommandTag(command);

  Serial.print(F("📱 App CMD: "));
  Serial.println(cmdTag);

  bool recognized = true;
  bool ok = true;
  String detail = "";

  if (cmdUpper == "LIGHT_ON")
  {
    setLight(true, "app");
  }
  else if (cmdUpper == "LIGHT_OFF")
  {
    setLight(false, "app");
  }
  else if (cmdUpper == "FAN_ON")
  {
    setFan(true, "app");
  }
  else if (cmdUpper == "FAN_OFF")
  {
    setFan(false, "app");
  }
  else if (cmdUpper == "EMERGENCY")
  {
    triggerEmergency("app");
  }
  else if (cmdUpper == "EMERGENCY_CLEAR")
  {
    clearEmergency("app");
  }
  else if (cmdUpper == "CALL_NURSE")
  {
    callNurse("app");
  }
  else if (cmdUpper == "ACK_NURSE")
  {
    acknowledgeNurseCall("app");
  }
  else if (cmdUpper == "GET_STATE")
  {
    sendStateToApp();
  }
  else if (cmdUpper == "GET_LOG")
  {
    sendEventLog();
  }
  else if (cmdUpper == "GET_CONFIG")
  {
    sendConfigToApp();
  }
  else if (cmdUpper == "VERIFY_CONFIG" || cmdUpper == "GET_CONFIG_VERIFY")
  {
    bool persisted = verifySettingsInNVS();
    ok = persisted;
    detail = persisted ? "NVS_OK" : "NVS_MISMATCH";
    sendConfigToApp();
  }

  // reset command for SIM800L, in case it gets into a bad state. App can trigger this and then wait for network status to become ready again.
  else if (cmdUpper == "RESET_GSM")
  {
    digitalWrite(SIM800_RST_PIN, LOW);
    delay(100);
    digitalWrite(SIM800_RST_PIN, HIGH);
    netState.networkReady = false;
    Serial.println(F("🔄 SIM800L reset triggered"));
    sendStateToApp();
  }

  // Settings sync from app
  else if (cmdUpper.startsWith("SET_BED:") ||
           cmdUpper.startsWith("SET_BED=") ||
           cmdUpper.startsWith("BED:") ||
           cmdUpper.startsWith("BED="))
  {
    String newBed = trimAtNextCommandToken(extractSettingValue(command));
    if (newBed.length() == 0)
    {
      ok = false;
      detail = "BED_EMPTY";
    }
    else
    {
      PATIENT_BED = newBed;
      persistAllSettings();
      bool persisted = verifySettingsInNVS();
      Serial.println(F("✓ Bed updated"));
      detail = persisted ? "BED_SAVED_NVS_OK" : "BED_SAVED_NVS_MISMATCH";
      logEvent("Config updated: bed");
      sendStateToApp();
      sendConfigToApp();
    }
  }
  else if (cmdUpper.startsWith("SET_NURSE:") ||
           cmdUpper.startsWith("SET_NURSE=") ||
           cmdUpper.startsWith("SET_NURSE_PHONE:") ||
           cmdUpper.startsWith("SET_NURSE_PHONE=") ||
           cmdUpper.startsWith("NURSE:") ||
           cmdUpper.startsWith("NURSE=") ||
           cmdUpper.startsWith("NURSE_PHONE:") ||
           cmdUpper.startsWith("NURSE_PHONE="))
  {
    String newNurse = sanitizePhoneNumberValue(extractSettingValue(command));
    if (newNurse.length() == 0)
    {
      ok = false;
      detail = "NURSE_INVALID";
    }
    else
    {
      NURSE_PHONE = newNurse;
      persistAllSettings();
      bool persisted = verifySettingsInNVS();
      Serial.println(F("✓ Nurse updated"));
      detail = persisted ? "NURSE_SAVED_NVS_OK" : "NURSE_SAVED_NVS_MISMATCH";
      logEvent("Config updated: nurse phone");
      sendConfigToApp();
    }
  }
  else if (cmdUpper.startsWith("SET_DOCTOR:") ||
           cmdUpper.startsWith("SET_DOCTOR=") ||
           cmdUpper.startsWith("SET_DOCTOR_PHONE:") ||
           cmdUpper.startsWith("SET_DOCTOR_PHONE=") ||
           cmdUpper.startsWith("DOCTOR:") ||
           cmdUpper.startsWith("DOCTOR=") ||
           cmdUpper.startsWith("DOCTOR_PHONE:") ||
           cmdUpper.startsWith("DOCTOR_PHONE="))
  {
    String newDoctor = sanitizePhoneNumberValue(extractSettingValue(command));
    if (newDoctor.length() == 0)
    {
      ok = false;
      detail = "DOCTOR_INVALID";
    }
    else
    {
      DOCTOR_PHONE = newDoctor;
      persistAllSettings();
      bool persisted = verifySettingsInNVS();
      Serial.println(F("✓ Doctor updated"));
      detail = persisted ? "DOCTOR_SAVED_NVS_OK" : "DOCTOR_SAVED_NVS_MISMATCH";
      logEvent("Config updated: doctor phone");
      sendConfigToApp();
    }
  }
  else
  {
    recognized = false;
    ok = false;
    detail = "UNKNOWN_COMMAND";
  }

  if (recognized)
  {
    logEvent("BLE command: " + cmdTag);
  }

  sendAppAck(ok, command, detail);
}

// ═══════════════════════════════════════════════════════════════════
// BLE CALLBACKS
// ═══════════════════════════════════════════════════════════════════
class ServerCallbacks : public BLEServerCallbacks
{
  void onConnect(BLEServer *pServer)
  {
    deviceConnected = true;
    bleLastStatePushAt = 0;
    Serial.println(F("📱 App connected"));
    sendStateToApp();
  }
  void onDisconnect(BLEServer *pServer)
  {
    deviceConnected = false;
    Serial.println(F("📱 App disconnected"));
  }
};

class CharacteristicCallbacks : public BLECharacteristicCallbacks
{
  void onWrite(BLECharacteristic *pCharacteristic)
  {
    String rxChunk = pCharacteristic->getValue().c_str();
    if (rxChunk.length() > 0)
    {
      bleRxBuffer += rxChunk;
      bleLastChunkAt = millis();

      // Flush immediately for short chunks; otherwise timeout-based flush handles fragmented writes.
      if (rxChunk.length() < 20)
      {
        processBleBufferedCommand(true);
      }
    }
  }
};

// ═══════════════════════════════════════════════════════════════════
// BLE SETUP
// ═══════════════════════════════════════════════════════════════════
void setupBLE()
{
  BLEDevice::init(DEVICE_NAME);
  BLEDevice::setMTU(185);
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  pCharacteristic = pService->createCharacteristic(
      CHARACTERISTIC_UUID,
      BLECharacteristic::PROPERTY_READ |
          BLECharacteristic::PROPERTY_WRITE |
          BLECharacteristic::PROPERTY_NOTIFY);

  pCharacteristic->addDescriptor(new BLE2902());
  pCharacteristic->setCallbacks(new CharacteristicCallbacks());

  pService->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println(F("✓ BLE initialized - HospitalAssistant"));
}

// ═══════════════════════════════════════════════════════════════════
// BLE RECONNECTION HANDLER
// ═══════════════════════════════════════════════════════════════════
void handleBLEReconnection()
{
  processBleBufferedCommand(false);

  if (!deviceConnected && oldDeviceConnected)
  {
    delay(500);
    pServer->startAdvertising();
    Serial.println(F("📡 BLE advertising restarted"));
    oldDeviceConnected = deviceConnected;
  }
  if (deviceConnected && !oldDeviceConnected)
  {
    oldDeviceConnected = deviceConnected;
  }

  if (deviceConnected && (millis() - bleLastStatePushAt) >= BLE_STATE_PUSH_INTERVAL)
  {
    sendStateToApp();
    bleLastStatePushAt = millis();
  }
}

#endif