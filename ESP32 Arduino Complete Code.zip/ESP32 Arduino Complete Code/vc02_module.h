#ifndef VC02_MODULE_H
#define VC02_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "state.h"
#include "relay_module.h"
#include "sim800_module.h"

// ═══════════════════════════════════════════════════════════════════
// UART OBJECT
// ═══════════════════════════════════════════════════════════════════
HardwareSerial VC02Serial(1);

// ═══════════════════════════════════════════════════════════════════
// RECEIVED VALUE
// ═══════════════════════════════════════════════════════════════════
unsigned int vc02ReceivedValue = 0;
const unsigned long ALERT_SMS_DEDUP_WINDOW_MS = 7000;
unsigned long lastEmergencyTriggerAt = 0;
unsigned long lastNurseTriggerAt = 0;

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setupVC02()
{
  VC02Serial.begin(9600, SERIAL_8N1, VC02_RX_PIN, VC02_TX_PIN);
  delay(100);
  Serial.println(F("✓ VC-02 initialized"));
}

// ═══════════════════════════════════════════════════════════════════
// EMERGENCY TRIGGER
// ═══════════════════════════════════════════════════════════════════
void triggerEmergency(String source)
{
  unsigned long now = millis();
  if (lastEmergencyTriggerAt != 0 &&
      (now - lastEmergencyTriggerAt) < ALERT_SMS_DEDUP_WINDOW_MS)
  {
    state.lastSource = source;
    Serial.println(F("⚠️ Emergency duplicate trigger ignored (debounce window)"));
    logEvent("Emergency duplicate ignored via " + source);
    sendStateToApp();
    return;
  }

  lastEmergencyTriggerAt = now;

  state.emergencyActive = true;
  state.lastCommand = "EMERGENCY";
  state.lastSource = source;

  Serial.println(F("🚨 EMERGENCY ALERT!"));
  Serial.print(F("   Source: "));
  Serial.println(source);
  logEvent("Emergency triggered via " + source);

  // Buzzer always works
  triggerBuzzer();

  String msg = "EMERGENCY ALERT!\nLocation: " + PATIENT_BED +
               "\nPatient requires IMMEDIATE assistance!";
  bool smsOk = sendSMS(DOCTOR_PHONE, msg);
  if (!smsOk)
  {
    Serial.println(F("⚠️ Emergency SMS failed"));
    logEvent("Emergency SMS failed");
  }

  sendStateToApp();
}

void clearEmergency(String source)
{
  state.emergencyActive = false;
  lastEmergencyTriggerAt = 0;
  state.lastCommand = "EMERGENCY_CLEAR";
  state.lastSource = source;

  stopBuzzer();

  Serial.println(F("✅ Emergency cleared"));
  Serial.print(F("   Source: "));
  Serial.println(source);
  logEvent("Emergency cleared via " + source);

  sendStateToApp();
}

// ═══════════════════════════════════════════════════════════════════
// CALL NURSE
// ═══════════════════════════════════════════════════════════════════
void callNurse(String source)
{
  unsigned long now = millis();
  if (lastNurseTriggerAt != 0 &&
      (now - lastNurseTriggerAt) < ALERT_SMS_DEDUP_WINDOW_MS)
  {
    state.lastSource = source;
    Serial.println(F("⚠️ Nurse call duplicate trigger ignored (debounce window)"));
    logEvent("Nurse duplicate ignored via " + source);
    sendStateToApp();
    return;
  }

  lastNurseTriggerAt = now;

  state.nurseCallActive = true;
  state.lastCommand = "CALL_NURSE";
  state.lastSource = source;

  Serial.println(F("📞 Call Nurse"));
  logEvent("Nurse call triggered via " + source);

  String msg = "Nurse Call Request\nLocation: " + PATIENT_BED +
               "\nPatient needs assistance.";
  bool smsOk = sendSMS(NURSE_PHONE, msg);
  if (!smsOk)
  {
    Serial.println(F("⚠️ Nurse call SMS failed"));
    logEvent("Nurse call SMS failed");
  }

  sendStateToApp();
}

void acknowledgeNurseCall(String source)
{
  state.nurseCallActive = false;
  lastNurseTriggerAt = 0;
  state.lastCommand = "NURSE_ACK";
  state.lastSource = source;

  Serial.println(F("✅ Nurse call acknowledged"));
  Serial.print(F("   Source: "));
  Serial.println(source);
  logEvent("Nurse call acknowledged via " + source);

  sendStateToApp();
}

// ═══════════════════════════════════════════════════════════════════
// COMMAND DECODER
// ═══════════════════════════════════════════════════════════════════
void decodeVC02Command(uint16_t cmd)
{
  Serial.print(F("🎤 Voice CMD: 0x"));
  Serial.println(cmd, HEX);

  switch (cmd)
  {
  case CMD_WAKEUP:
    Serial.println(F("   Wake word detected"));
    break;
  case CMD_EMERGENCY:
    triggerEmergency("voice");
    break;
  case CMD_CALL_NURSE:
    callNurse("voice");
    break;
  case CMD_LIGHT_ON:
    setLight(true, "voice");
    break;
  case CMD_LIGHT_OFF:
    setLight(false, "voice");
    break;
  case CMD_FAN_ON:
    setFan(true, "voice");
    break;
  case CMD_FAN_OFF:
    setFan(false, "voice");
    break;
  default:
    Serial.print(F("   Unknown: 0x"));
    Serial.println(cmd, HEX);
    break;
  }
}

// ═══════════════════════════════════════════════════════════════════
// COMMAND PROCESSOR
// ═══════════════════════════════════════════════════════════════════
void processVC02Commands()
{
  if (VC02Serial.available() > 0)
  {
    byte highByte = VC02Serial.read();

    unsigned long t = millis();
    while (VC02Serial.available() == 0)
    {
      if (millis() - t > 50)
        return;
    }

    byte lowByte = VC02Serial.read();
    vc02ReceivedValue = (highByte << 8) | lowByte;

    Serial.print(F("Received HEX: 0x"));
    Serial.println(vc02ReceivedValue, HEX);

    decodeVC02Command(vc02ReceivedValue);
    vc02ReceivedValue = 0;

    while (VC02Serial.available())
      VC02Serial.read();
  }
}

#endif