/*
 * ═══════════════════════════════════════════════════════════════════
 * HOSPITAL VOICE ASSISTANT - COMPLETE INTEGRATED SYSTEM v4.0
 * ═══════════════════════════════════════════════════════════════════
 *
 * Modular Architecture:
 * - config.h        → Pin definitions, UUIDs, constants
 * - state.h         → Device & network state structs
 * - relay_module.h  → Light, fan, buzzer control
 * - sim800_module.h → GSM/SMS functions
 * - vc02_module.h   → Voice recognition processing
 * - switch_module.h → Physical switch handling
 * - ble_module.h    → Bluetooth LE communication
 *
 * Author: Abubakar Zubair Okhayole
 * Institution: Bayero University Kano
 * Project: Final Year Project
 * ═══════════════════════════════════════════════════════════════════
 */

#include <Preferences.h>
#include "config.h"
#include "state.h"
#include "relay_module.h"
#include "sim800_module.h"
#include "vc02_module.h"
#include "switch_module.h"
#include "ble_module.h"

// ═══════════════════════════════════════════════════════════════════
// GLOBAL STATE DEFINITIONS
// ═══════════════════════════════════════════════════════════════════
DeviceState state;
NetworkState netState;
EventLogState eventLog;

String NURSE_PHONE = DEFAULT_NURSE_PHONE;
String DOCTOR_PHONE = DEFAULT_DOCTOR_PHONE;
String PATIENT_BED = DEFAULT_PATIENT_BED;

Preferences settingsStore;
bool settingsReady = false;

void setupPersistentSettings()
{
  settingsReady = settingsStore.begin("hosp_cfg", false);
  if (!settingsReady)
  {
    Serial.println(F("⚠️ Settings storage init failed"));
    return;
  }

  NURSE_PHONE = settingsStore.getString("nurse", DEFAULT_NURSE_PHONE);
  DOCTOR_PHONE = settingsStore.getString("doctor", DEFAULT_DOCTOR_PHONE);
  PATIENT_BED = settingsStore.getString("bed", DEFAULT_PATIENT_BED);

  if (NURSE_PHONE.length() == 0)
    NURSE_PHONE = DEFAULT_NURSE_PHONE;
  if (DOCTOR_PHONE.length() == 0)
    DOCTOR_PHONE = DEFAULT_DOCTOR_PHONE;
  if (PATIENT_BED.length() == 0)
    PATIENT_BED = DEFAULT_PATIENT_BED;

  Serial.println(F("✓ Settings loaded from NVS"));
}

void persistAllSettings()
{
  if (!settingsReady)
  {
    return;
  }

  settingsStore.putString("nurse", NURSE_PHONE);
  settingsStore.putString("doctor", DOCTOR_PHONE);
  settingsStore.putString("bed", PATIENT_BED);
}

void logEvent(const String &eventText)
{
  String line = String(millis()) + "ms | " + eventText;
  eventLog.entries[eventLog.head] = line;
  eventLog.head = (eventLog.head + 1) % EVENT_LOG_CAPACITY;
  if (eventLog.count < EVENT_LOG_CAPACITY)
  {
    eventLog.count++;
  }

  Serial.print(F("📝 Event: "));
  Serial.println(line);
}

String getEventLogDump()
{
  if (eventLog.count == 0)
  {
    return "EMPTY";
  }

  String dump = "";
  int start = (eventLog.head - eventLog.count + EVENT_LOG_CAPACITY) % EVENT_LOG_CAPACITY;

  for (int i = 0; i < eventLog.count; i++)
  {
    int idx = (start + i) % EVENT_LOG_CAPACITY;
    if (i > 0)
    {
      dump += " || ";
    }
    dump += eventLog.entries[idx];
  }

  return dump;
}

// ═══════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════
void setup()
{
  Serial.begin(9600);
  delay(1000);

  setupPersistentSettings();

  printStartupBanner();
  logEvent("System boot");

  setupPins();
  initPhysicalSwitches();
  setupVC02();
  setupSIM800();
  setupBLE();
}

// ═══════════════════════════════════════════════════════════════════
// MAIN LOOP
// ═══════════════════════════════════════════════════════════════════
void loop()
{
  processVC02Commands();
  checkPhysicalSwitches();
  updateBuzzer();
  checkNetworkStatus();
  processSIM800Responses();
  handleBLEReconnection();
  delay(10);
}

// ═══════════════════════════════════════════════════════════════════
// STARTUP BANNER
// ═══════════════════════════════════════════════════════════════════
void printStartupBanner()
{
  Serial.println(F("\n╔════════════════════════════════════════════════════╗"));
  Serial.println(F("║   HOSPITAL VOICE ASSISTANT - SYSTEM v4.0           ║"));
  Serial.println(F("║   Bayero University Kano | ENG/19/ELE/00265        ║"));
  Serial.println(F("╚════════════════════════════════════════════════════╝"));
  Serial.println(F("✓ Modular architecture loaded"));
  Serial.println(F("✓ VC-02:    GPIO 12 (RX) & GPIO 14 (TX)"));
  Serial.println(F("✓ SIM800L:  GPIO 26 (RX) & GPIO 27 (TX)"));
  Serial.println(F("✓ Light:    GPIO 32 | Fan: GPIO 33"));
  Serial.println(F("✓ Buzzer:   GPIO 25 (2s beeps)"));
  Serial.println(F("✓ Switches: GPIO 34 & GPIO 35"));
  Serial.println(F("✓ BLE:      HospitalAssistant"));
  Serial.println(F("════════════════════════════════════════════════════\n"));
}